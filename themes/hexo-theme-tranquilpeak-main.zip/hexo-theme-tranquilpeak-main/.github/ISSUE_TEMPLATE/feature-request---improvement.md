---
name: Feature request / improvement
about: Suggest a feature or an improvement
title: ''
labels: ''
assignees: LouisBarranqueiro

---

### Description
<!-- Clearly describe what you want to happen. -->


### Explanation / motivation
<!-- Clearly describe why you need this feature / improvement. -->


### Additional information
- [ ] I can implement this feature / improvement <!-- Check this box if you can work on it and create a pull request -->
